TABULA

wiki Church Clock example:

1. {3} * {2} * {1} instead of reverse
(suggest for + and * use numerical order)

2. ac.si in item 3 instead of m/s^2

3. Shift-Click H - flag ! is at the end of the name.
The wiki says it should be against the item number.

4. "Item 8 may become not 0 but a tiny value.
A second click of 01 will cure that."
- it did not when holding the mass of weight, leaving a small number in item 8 (on 64-bit system).

wiki Elephants example:

1. arrows in display in wiki (below) not same as on screen

( needs fixed font... )

launch an elephant into orbit
    ┌  1        1.000 grav      g:feeder
  ┌ ├  2        1.000 eq.r      equatorial radius of earth!
┌ │ └> 3       84.426 min       earth orbital period
├ └>   4      4.008E7 m         circumference of circle
└>  ┌  5    28480.540 km/h      speed in orbit
    ├  6        1.000 elephant  standard African elephant!
    └> 7 @   1.064E11 J         kinetic energy

2.